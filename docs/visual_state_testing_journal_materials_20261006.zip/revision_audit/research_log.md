# Journal revision log — 2026-10-06

Read the retained final controls manuscript and verified official Software Quality Journal author requirements. Reorganized results into three RQs and wrote Chinese/English main manuscripts. Preserved full historical evidence without overwriting existing manuscripts or model outputs.

Generated a separate extended-results supplement and local evidence package. Used the publisher's December 2024 template downloaded from its official author-support link, retaining unmodified sn-jnl.cls and sn-basic.bst.

Numeric checks cover retained risk, ablation, mixture, ranking, selection, frozen-state, case, attribute-reference and agreement results. Four newly composed figures use actual retained data, English labels, shared scales, explicit units and editable text.

Attempted LaTeX compilation using a local Tectonic runtime. Default and direct bundle endpoints failed while retrieving required TeX resources; no PDF was claimed from those attempts. Word export and direct SVG/PNG inspection remain available independently of the failed TeX-resource download.

No new training/VLM requests, human review, external repository publication or journal submission were performed.
