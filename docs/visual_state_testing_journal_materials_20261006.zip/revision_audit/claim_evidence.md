# Claim–evidence map

| Claim | Main location | Retained evidence | Scope |
|---|---|---|---|
| Risk gaps exceed random grouping | RQ1, Table 3, Figure 2 | random_stratification_ablation_20261006/tables/random_summary.csv; full-stratum NPZ | Fixed targets and model panel; not all alternative stratifications |
| Direction survives dimension removal | RQ1, Table 4 | ablation_summary.csv, all 42 rows in SI | No corrected dimension-specific conclusion; membership changes |
| Risk composition changes measured capability | RQ2, Table 5, Figure 3 | controlled_risk_distribution_20261005/tables/panel_summary.csv and distribution_contrasts.csv | Fixed 120 targets, equal classes; sampling ranges are not mean CIs |
| Leading mean ranks recur | RQ2, Table 6 | full-stratum NPZ; model_summary.csv; rank uncertainty tables | Studied training recipe and architectures; not universal ranking |
| Coverage breadth gain is conditional | RQ3, Table 7 | All three comparison/tables/comparisons.csv files; SI Tables S3–S5 | Main four-family support differs from all-20 and strong-baseline corrections |
| Frozen weaknesses can recur | RQ3, Tables 8–9, Figure 4 | Three transfer/tables/comparisons.csv and state_validation.csv | Supported state associations; overlapping conditions; no repair claim |
| Label uncertainty remains material | Validity, Tables 10–11 | attribute_metrics.csv; retention_distribution.csv | Partial official reference only; strict agreement endpoints not estimable |

Official format: https://link.springer.com/journal/11219/submission-guidelines (checked 2026-10-06). The journal-specific mandatory sn-jnl requirement takes precedence over the generic Word-accepted paragraph. Official aims/scope support topical fit, not a quartile or acceptance-probability claim.

Bibliographic verification uses primary arXiv records, author-released papers, publishers and official dataset resources. DOI updates for DeepXplore, DeepGauge and DeepGini were verified against primary records. Related diversity/coverage work is acknowledged; no first-ever objective or direct DeepGD superiority is claimed.
