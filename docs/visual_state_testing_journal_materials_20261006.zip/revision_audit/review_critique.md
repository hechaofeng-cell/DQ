# Editorial review

The former 28-numbered-table/17-figure manuscript is an evidence archive. The revised main article has three RQs, eleven tables and four figures; all primary negative boundaries remain in the main text. This is an editorial choice, not an invented journal page limit.

Resolved: scattered Objects365 additions; ambiguous coverage-versus-risk claims; confusion of classifier F1 with attribute-reference F1; mixed interval descriptions; unqualified stable-rank language; incomplete declaration structure; numeric citation style; abstract length/keyword count; opaque selection AUC interpretation.

Retained limitations: no complete human state truth; correlated risk dimensions; limited independent architecture units; post hoc cached checks; nonconverged mixed-effects fit; VOC support limits; incomplete strict-agreement support; pretrained-data overlap uncertainty; no repair experiment; no general strong-baseline superiority.

Checks: recompute main numeric tables from CSV/NPZ, verify sequence and counts, inspect figure exports, validate editable SVG text and absence of raster embedding, verify Word table/picture/math structure, and check official class provenance. No training or labeling is rerun.

Outstanding author facts: identity/affiliations/contact, funding, interests, contribution allocation, applicable ethics/permissions and actual repository access. No external submission or data publication occurs. LaTeX compile verification is a separate technical check and must not be reported as passed unless it actually passes.
