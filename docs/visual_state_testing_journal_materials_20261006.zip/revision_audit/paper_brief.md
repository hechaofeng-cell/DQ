# Revision brief

Task: optimize the retained manuscript for a realistic empirical model-testing journal submission, without new classifier/VLM experiments or invented outcomes. Software Quality Journal supplies the concrete official format; no current CAS/JCR quartile is asserted.

Primary claim: predefined output-independent visual-risk strata provide reproducible conditional performance distinctions in the evaluated six-class, 24-classifier, three-confirmation-pool setting.

Secondary claim: frozen state descriptions can specify and confirm follow-up test conditions when target support is adequate. Coverage selection breadth is conditional; universal algorithm superiority, complete state-label accuracy and causal error diagnosis are outside the claim.

Deliverables: Chinese and English manuscript review copies, extended English supplement, source-table evidence bundle, official-template LaTeX, change/requirement note, and numeric/structural audits. Author facts and public data access remain explicit placeholders.
