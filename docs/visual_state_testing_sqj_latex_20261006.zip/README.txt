Review draft: fill actual authors, funding, conflicts, contributions and data access before submission.
Compile main.tex with pdflatex (twice). Bibliography is embedded; author-year citations are explicit in the text.
The official sn-jnl.cls and sn-basic.bst are unchanged template files. Figures use English labels and embedded fonts.
The supplement is a separate document. This source bundle does not include raw images or full prediction caches.
