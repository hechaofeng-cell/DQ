# Claim-to-evidence map

| Claim | Evidence | Scope and interpretation |
|---|---|---|
| Automatic risk strata separate measured classifier performance | Historical full-risk layer tables and random-stratification controls; new run_metrics.csv reproduces historical membership metrics | Fixed classifiers and the defined pipelines/pools; no semantic accuracy claim |
| Full VLM risk is uniformly better than area alone | New tables/summary.csv, exact paired inference | Unsupported; none of the three positive contrasts passes six-test Holm; D area is stronger for both annotators |
| Some non-scale conditions retain a diagnostic association within coarse area layers | area_condition_summary.csv includes all 141 frozen non-scale hypotheses; B109/119 and D111/122 eligible mean differences are negative | Descriptive overlapping combinations; not independent defects, precise area matching or causal attribution; C has only four evaluable combinations |
| Coverage adds failure breadth under specified equal-error random controls | Historical equal_error_metrics.csv and comparisons.csv; standalone 60-contrast reaggregation; practical_breadth.csv | Main four-test family distinct from all-20 and strong-baseline families; negative/unsupported contrasts remain |
| VLM annotations are semantically accurate | Existing attribute-reference and agreement sensitivity outputs only | Not established without suitable truth; agreement and performance separation do not validate every state |
| Cases illustrate classifier and preprocessing errors | Four target hashes, cached predictions, exact Resize/CenterCrop input, case_manifest.json | Outcome-selected illustrations; do not estimate prevalence or certify state labels |
| Closest related work differs in information access and purpose | Verified Domino, VLSlice, What to Test Next primary papers, updated related-work section | Positioning comparison, not a performance baseline or novelty priority claim |
| Cached results can be independently reanalyzed | Portable inputs, two standalone scripts, manifest and extraction replay audit | Reanalysis without GPU/network; not from-scratch classifier training, VLM service replay or feature/cluster reconstruction |

Revision v2 synchronizes both companion reports with the manuscript. It adds no experiment, reference or stronger thesis. The strongest allowed wording remains conditional performance organization and reusable diagnosis in the evaluated setting; superiority, semantic truth, causal root causes and repair benefits remain unsupported. Report tables are checked against the same source outputs.
