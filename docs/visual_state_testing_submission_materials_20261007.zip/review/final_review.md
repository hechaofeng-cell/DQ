# Final review gates

Research intent is testing/diagnosis rather than improving F1 or proving universal Coverage superiority. All favorable, negative and unsupported outcomes remain in the manuscript. The area baseline adds a serious boundary to the earlier interpretation.

Scientific gates: eight architecture units with seeds averaged; six scale contrasts corrected together; hierarchy intervals conditional on fixed targets; tie ranges not confidence intervals; coarse area adjustment not causality; descriptive hypothesis counts not independent discoveries; real cases not human truth; category-containing VLM protocol not blind recognition.

Reproducibility gates: unchanged source hashes, all original numeric tables preserved, bilingual table numbers matched, complete new source-table mapping, cached full-risk cells checked, ZIP integrity and independent extraction replay. Machine-readable audit.json and portable_replay_audit.json record final outcomes.

Recorded local result: these numeric/structural and extraction-replay gates pass. All eight portable scale tables and 60 historical selection comparisons match; both main Word documents contain 13 tables, six figures and three editable display equations. The supplement has nine tables. Complete author facts and a compiled/rastered page review remain separate from these passed checks.

Presentation gates: editable SVG/PDF/EPS/PNG figures, actual classifier inputs displayed, readable effect contrasts, Word tables/images/equations checked. Full-page Word rendering and compiled LaTeX PDF are not established and must not be reported as passed.

Submission facts pending by agreement: author/affiliation/funding/contribution/conflict declarations, persistent public access and per-image publication rights for displayed images. The local empirical analysis closeout does not resolve these factual publication steps or guarantee acceptance.

Revision v2 review: report claims and paper discussion agree on area-only strength, descriptive residual condition associations, semantic uncertainty, preprocessing and the cached-reanalysis boundary. Obsolete missing-control/material statements are removed. Result gate is checked by sync_latest_reports.py against source tables; no new citation or experimental claim is introduced, and the established citation gate remains unchanged. Claim-scope gate passes for this bounded revision.
