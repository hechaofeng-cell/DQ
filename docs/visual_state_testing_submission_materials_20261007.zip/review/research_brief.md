# Research brief: submission closeout

Date: 2026-10-07. Scope: six-class visual-state testing, eight frozen architectures and three seeds, three confirmation pools. Complete a metadata-only control, nearest-work positioning, reproducible cached analysis and illustrative actual-input cases; revise Chinese/English manuscripts and supplementary material.

No new classifier training/inference, no VLM calls, no human semantic review, no model repair and no public upload are in scope. Author facts remain pending at the user's request. Preserve original manuscripts and caches.

The area-control supplementary analysis was designed after historical outcomes were known. Freeze the negative continuous-area baseline, equal within-class quintiles, score/ID tie rules, G=Q1−Q5, architecture-level paired inference, separate six-comparison Holm correction and non-scale historical hypotheses before executing this analysis. Never pick favorable new states or models after viewing its outcome.

Deliverables: complete scale/conditional diagnostic outputs; editable figures; real target/input/prediction cases; 13-table, six-figure bilingual manuscripts; S1–S14 supplement; standalone portable reanalysis; claim map and audit. Success means bounded, reproducible evidence, not a positive or statistically significant preferred result.
