# 模型对比结果的证据边界

| 结论 | 复算输出 | 可以使用的解释 | 边界 |
|---|---|---|---|
| 主组总体与dog表现不同 | overall_runs.csv、model_summary.csv | 同池三种子平均的观察差异 | 不宣称通用或显著架构排名 |
| Coverage的诊断增量因模型而异 | diagnostic_auc_runs.csv | 模型内同风险配额、等错误数的AUC差 | 不给单模型显著性星号，错误簇分母因模型变化 |
| 主组共用状态覆盖值 | shared_coverage.csv | 600目标时频次覆盖增加 | 不是每个模型独有覆盖或准确率增益 |
| 五层与高低层表现不同 | tier_runs.csv、tier_summary.csv | 共同层的条件表现 | 不保证其他来源或任务严格单调 |
| 测试构成引起测得成绩变化 | mixture_curves.csv、mixture_endpoints.csv | 120目标固定预算的构成响应 | 不是训练收益，抽样区间不是部署置信区间 |
| 共同状态表现存在模型差别 | common_condition_comparison.csv | 同一条件目标上的Recall与模型内相对差 | 四个说明案例，状态关联不是错误因果 |
| 候选条件可在新目标继续检查 | condition_confirmation_models.csv | 既定条件平均负差／非负／支持不足 | 模型清单不同，不比较原始数量为架构能力 |
| 扩展五模型存在端点差及种子波动 | extension_summary.csv、extension_overall_runs.csv | 同一主设置中的扩展观察 | 不继承主8模型的覆盖或风险对照结论 |

复算命令：`.venv/bin/python scripts/build_model_comparison_teacher_20261012.py`。
源文件校验值、各项重算及图表数量见 result_audit.json 与 document_audit.json。
