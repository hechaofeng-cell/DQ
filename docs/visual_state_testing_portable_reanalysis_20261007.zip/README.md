# 便携缓存复算入口

解压`visual_state_testing_portable_reanalysis_20261007.zip`，在解压根目录执行以下命令。它复用冻结预测，不需要网络、GPU、原图或API密钥。

```bash
python scripts/run_scale_only_confirmation.py --input portable_inputs --output reproduced_scale
python scripts/reaggregate_selection_evidence.py --input historical_selection --output reproduced_selection
```

如当前环境缺少依赖，可先在已有Python虚拟环境安装`requirements_reanalysis.txt`所列版本。版本文件来自本次观测环境，不是项目初始训练容器的完整锁定。

`reproduced_scale/tables/summary.csv`应与`expected_scale_tables/summary.csv`一致；成员、支持量、unknown、面积调整条件及逐运行指标均可比较。`reproduced_selection`重新计算三池全部60项效应均值、精确符号翻转p及四类Holm校正，并与历史比较表核对；它使用既有等错误数指标，不重新提取表征或重做聚类，历史bootstrap区间仍以原表为证据。

## 文件与复现层级

| 目录/文件 | 内容 | 支持的复现 |
|---|---|---|
| portable_inputs | 三池5400目标、双VLM状态、24份预测/logits、风险部件、历史完整分层、冻结假设 | 新尺度实验与历史完整风险层从目标级缓存重算 |
| historical_selection | 固定共同配额、选样顺序、随机顺序、预算指标和原比较表 | 选择对照聚合及校正重算 |
| mixture_cache | 六设置、21点、1000抽样、24运行的实际性能/Recall缓存 | 既有性能曲线和区间从抽样级结果重聚合 |
| historical_results / historical_evidence_tables | 确认、条件转移、一致性、消融等扩展源表 | 表级审计与证据追溯，非所有原始流程重建 |
| prompts / configs | 原提示模板、字典追加后的请求文本、19/18原生和14共享字段schema | 审查实际状态定义和字段保留 |
| annotation_call_settings.json | 不含密钥的调用选项及其来源边界 | 本地代码选项、当前线上配置快照，不保证历史服务权重可重建 |
| source_audits | 样本排除、历史ID和阶段冻结记录 | 检查已记录排重规则与来源变化 |
| historical_implementation | 历史选样、表征、风险和标注代码的审阅快照 | 检查实现定义；不是完整独立工程或从零训练入口 |
| dataset_license_inventory.md | 官方许可来源与本地图示ID | 区分标注许可、图片权利及尚待确定的发布条件 |
| environment.json | 本次Python与包版本 | 分析/导出环境记录 |
| manifest.sha256.json | 包内文件SHA256 | 校验解压文件未变 |

原图、模型训练权重、所有原始服务响应、原分类器表征和训练特征未打包。源图应按各数据源规则获取；本地完整工程仍保留相应历史资料。本包没有假称可以从零重跑所有训练或历史线上模型调用。

## 定义与安全的解释

类别顺序固定为dog、cat、horse、sheep、person、car。每条预测对应官方标注派生的固定目标；person是人体对象，不是face。VLM自动状态不是人工真值。完整风险主分析使用中点unknown及sample_id并列规则；尺度基线使用连续面积，类内五分层。G为Q1−Q5 F1；增量为完整G−面积G，不能与原Q5−Q1符号混淆。

主检验八架构先平均三种子，六新增设置校正。1000次并列敏感性只在相同分数内随机，不是1000个独立架构。面积调整诊断控制五分位构成，不证明连续尺度完全控制或因果。

## 发布状态

这是本地审阅材料，尚未上传公共仓库或取得DOI。作者、资助、利益冲突、真实访问地址按用户要求暂待确定。原始图片许可和实际图示发布权限仍应按源记录核对，不能以提供缓存替代发布许可。
