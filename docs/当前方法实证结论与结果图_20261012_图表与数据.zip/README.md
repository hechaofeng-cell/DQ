# 当前方法实证结论与结果图

报告对应2026年10月12日的“说明完善版”方法章节，仅汇总已完成实验。

- 主面板：8架构×3种子；B/C/D三个确认池。
- 扩展面板：5架构×3种子，单独报告。
- figures：7幅图的可编辑SVG、高清PNG和矢量PDF。
- tables：绘图数据及主要结果的CSV。
- result_audit.json：原始CSV校验值与18项主结果复算记录。

图2是归一化预算广度AUC，不能当作F1提升。图5左侧是逐组合三种子均值方向，右侧是架构加权汇总，报告正文另外保留逐种子状态计数。图7是完整风险层的平均端点差，不是整体模型排名。

本报告未开展新训练、VLM调用或人工核验。Word与PDF由同一Markdown文本导出；PDF实际由LaTeX编译，不声称与Word逐页相同。

项目目录下运行 `.venv/bin/python scripts/plot_current_method_conclusions_20261012.py` 和 `.venv/bin/python scripts/plot_current_method_recent_extension_20261012.py` 可重建图表；需要原始实验CSV，代码中的路径按原项目结构读取。
