# 视觉状态驱动模型测试：研究方法章节

此目录包含完整章节的真实 LaTeX 源码，含全部九个编号公式、行内数学、符号表、风险表、算法正文、原图和中文字体。

使用 XeLaTeX 编译（建议安装含 xeCJK、fontspec、amsmath 的 TeX Live）：

```bash
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

也可在此目录运行 Tectonic：

```bash
tectonic --keep-logs main.tex
```

必须保留 `fonts/` 和 `figure_1.png` 与 `main.tex` 的相对位置。中英文字体已随包提供：中文为 Noto Sans SC，英文正文为 DejaVu Serif，数学使用 TeX 默认数学字体。

正文与公式对应 `论文方法章节_视觉状态驱动模型测试_LaTeX重编译版_20261012.md`。Word 文件的数学由同一源文中的 LaTeX 经 Pandoc 转为可编辑的 Office Math；PDF 由本目录的完整 LaTeX 章节实际编译得到，PDF 与 Word 的分页不保证相同。
