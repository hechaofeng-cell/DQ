# 编译说明

本目录包含完整方法章节的LaTeX源码、原图与字体。PDF以Tectonic实际编译；Word在用户上传底稿上仅替换有关正文段落，新行内数学由相同LaTeX源转换为原生Office Math。

运行 `tectonic --keep-logs --keep-intermediates main.tex` 即可编译。也可使用兼容XeLaTeX的环境，以 `xelatex main.tex` 编译。

Word沿用上传文档的字体与页面设置，PDF使用LaTeX版式；PDF不是Word分页渲染结果。原图保持不变，第3.7节不恢复。字体许可见fonts目录。
